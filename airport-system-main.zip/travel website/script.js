const navBar=document.getElementById('navBar');
